package com.ahmad.waterbilling;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private String pendingExport;
    private static final int REQ_EXPORT = 11;
    private static final int REQ_IMPORT = 12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0b5394"));
        getWindow().setNavigationBarColor(Color.parseColor("#ffffff"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#f2f6fb"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface
        public void share(String text, String title) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, title));
        }

        @JavascriptInterface
        public void whatsapp(String phone, String text) {
            Uri uri = Uri.parse("https://api.whatsapp.com/send?phone=" + phone + "&text=" + Uri.encode(text));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.setPackage("com.whatsapp");
            try {
                startActivity(i);
            } catch (Exception e) {
                try {
                    i.setPackage("com.whatsapp.w4b");
                    startActivity(i);
                } catch (Exception e2) {
                    i.setPackage(null);
                    startActivity(i);
                }
            }
        }

        @JavascriptInterface
        public void shareImage(String b64, String title) {
            Uri u = saveImage(b64);
            if (u == null) return;
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, title));
        }

        @JavascriptInterface
        public void whatsappImage(String phone, String b64) {
            Uri u = saveImage(b64);
            if (u == null) return;
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.putExtra("jid", phone + "@s.whatsapp.net");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setPackage("com.whatsapp");
            try {
                startActivity(i);
            } catch (Exception e) {
                try {
                    i.setPackage("com.whatsapp.w4b");
                    startActivity(i);
                } catch (Exception e2) {
                    i.setPackage(null);
                    startActivity(Intent.createChooser(i, "إرسال الصورة"));
                }
            }
        }

        @JavascriptInterface
        public void exportFile(String text, String name) {
            pendingExport = text;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, name);
            startActivityForResult(i, REQ_EXPORT);
        }

        @JavascriptInterface
        public void importFile() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_IMPORT);
        }

        @JavascriptInterface
        public void copy(String text) {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("water", text));
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم النسخ", Toast.LENGTH_SHORT).show());
        }
    }

    private Uri saveImage(String b64) {
        try {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            String name = "water_" + System.currentTimeMillis() + ".png";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WaterBilling");
                Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                OutputStream os = getContentResolver().openOutputStream(u);
                os.write(bytes);
                os.close();
                return u;
            } else {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> {
                        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 21);
                        Toast.makeText(this, "اسمح بالتخزين وبعدها جرّب مرة ثانية", Toast.LENGTH_LONG).show();
                    });
                    return null;
                }
                Bitmap bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                String s = MediaStore.Images.Media.insertImage(getContentResolver(), bm, name, null);
                return Uri.parse(s);
            }
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "خطأ بحفظ الصورة: " + e.getMessage(), Toast.LENGTH_LONG).show());
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            if (requestCode == REQ_EXPORT && pendingExport != null) {
                OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt");
                os.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                os.close();
                pendingExport = null;
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
            } else if (requestCode == REQ_IMPORT) {
                InputStream is = getContentResolver().openInputStream(data.getData());
                BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
                br.close();
                web.evaluateJavascript("window.onImport(" + JSONObject.quote(sb.toString()) + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "خطأ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.onBack&&window.onBack()", v -> {
            if (!"true".equals(v)) MainActivity.super.onBackPressed();
        });
    }
}
