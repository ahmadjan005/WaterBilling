# فواتير المياه – طريقة الحصول على ملف APK

1. افتح github.com وأنشئ مستودعاً جديداً (New repository) باسم WaterBilling.
2. ارفع ملف WaterBilling.zip كما هو (بدون فك الضغط).
3. أنشئ ملفاً جديداً (Add file ← Create new file) باسم:
   .github/workflows/build.yml
   والصق فيه محتوى ملف build.yml.
4. اذهب إلى Actions ← Build APK ← Run workflow (إذا لم يبدأ تلقائياً)، وانتظر 3-5 دقائق.
5. افتح التشغيل ← Artifacts ← حمّل WaterBilling-APK ← فك الضغط ← ثبّت app-debug.apk.
